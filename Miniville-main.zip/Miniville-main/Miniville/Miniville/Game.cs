﻿using System;

namespace Miniville
{
	public class Game
	{
		
	}
}

