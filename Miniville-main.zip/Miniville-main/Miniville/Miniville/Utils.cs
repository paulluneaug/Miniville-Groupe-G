﻿using System;

namespace Miniville
{
	public class Utils
	{
		public enum CardName
		{
			WheatField,
			Farm,
			Bakery,
			CofeeShop,
			SuperMarket,
			Forest,
			Restraurant,
			Stadium
		}
		public enum CardColor
		{
			Red,
			Green,
			Blue
		}
		public Utils()
		{
		}
	}
}

